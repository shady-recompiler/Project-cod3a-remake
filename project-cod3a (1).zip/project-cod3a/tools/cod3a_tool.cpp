#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "core/disc_verify.h"
#include "core/elf_loader.h"
#include "core/iso_reader.h"

using namespace cod3a;

static int usage() {
    std::fprintf(stderr,
                 "usage:\n"
                 "  cod3a_tool identify <disc.iso> [known_builds.txt]\n"
                 "  cod3a_tool elf-info <disc.iso>\n");
    return 2;
}

int main(int argc, char** argv) {
    if (argc < 3) return usage();
    std::string cmd = argv[1];

    IsoReader iso;
    if (!iso.open(argv[2])) {
        std::fprintf(stderr, "Could not open %s as a 2048-byte-sector ISO9660 image.\n", argv[2]);
        return 1;
    }

    if (cmd == "identify") {
        std::vector<KnownBuild> known;
        if (argc >= 4) known = loadKnownBuilds(argv[3]);
        VerifyResult r = verifyDisc(iso, known);
        std::printf("serial : %s\nregion : %s\nelf    : %s\ncrc32  : %08X\nresult : %s\n",
                    r.serial.c_str(), r.region.c_str(), r.elfName.c_str(), r.elfCrc32, r.message.c_str());
        if (r.verdict == Verdict::UnknownBuild)
            std::printf("\nTo accept this disc, add this line to data/known_builds.txt:\n%s %08X\n", r.serial.c_str(), r.elfCrc32);
        return r.verdict == Verdict::Ok ? 0 : 1;
    }

    if (cmd == "elf-info") {
        VerifyResult r = verifyDisc(iso, {});
        if (r.elfName.empty()) { std::fprintf(stderr, "%s\n", r.message.c_str()); return 1; }
        IsoEntry e;
        std::vector<uint8_t> data;
        ElfInfo info;
        std::string err;
        if (!iso.find(r.elfName, e) || !iso.read(e, data) || !parseElf(data, info, err)) {
            std::fprintf(stderr, "ELF error: %s\n", err.c_str());
            return 1;
        }
        std::printf("entry: 0x%08X\n", info.entry);
        for (const auto& s : info.loadSegments)
            std::printf("segment vaddr=0x%08X filesz=0x%X memsz=0x%X flags=%u\n", s.vaddr, s.fileSize, s.memSize, s.flags);
        return 0;
    }
    return usage();
}

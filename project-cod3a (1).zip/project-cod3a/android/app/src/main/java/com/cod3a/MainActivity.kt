package com.cod3a

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var btnPick: Button
    private lateinit var btnPlay: Button
    private lateinit var btnCredit: Button

    private var deviceOk = false
    private var verifiedIso: Uri? = null

    private val prefs by lazy { getSharedPreferences("cod3a", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val d = resources.displayMetrics.density
        val pad = (24 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "Project cod3a"
            textSize = 30f
            gravity = Gravity.CENTER
        })
        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, pad)
        }
        root.addView(status)

        btnPick = menuButton("Pick the file folder") { openFolderPicker() }
        btnPlay = menuButton("Play") { onPlay() }
        btnCredit = menuButton("Credit") { showCredit() }
        root.addView(btnPick)
        root.addView(btnPlay)
        root.addView(btnCredit)

        root.addView(TextView(this).apply {
            text = "You must supply your own legally dumped USA PS2 disc image. No game files are included in this app."
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(0, pad, 0, 0)
        })
        setContentView(root)

        checkDevice()
        restoreSavedDisc()
        if (deviceOk && verifiedIso == null) status.text = "${status.text}\n\n$NO_ISO_MESSAGE"
    }

    private fun menuButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    // ---- device ----

    private fun checkDevice() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val ramMB = (mem.totalMem / (1024 * 1024)).toInt()
        val gl = am.deviceConfigurationInfo.reqGlEsVersion
        val soc = if (Build.VERSION.SDK_INT >= 31) Build.SOC_MODEL else Build.HARDWARE

        val result = NativeBridge.evaluateDevice(ramMB, soc, gl shr 16, gl and 0xFFFF)
        val tier = result.substringBefore('|')
        deviceOk = tier != "Unsupported"
        btnPick.isEnabled = deviceOk
        btnPlay.isEnabled = deviceOk
        status.text = "Device: $soc, $ramMB MB RAM\n${result.substringAfter('|')}"
    }

    // ---- folder picking (works for internal storage and SD cards) ----

    private fun openFolderPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        startActivityForResult(i, REQ_FOLDER)
    }

    @Deprecated("Kept dependency-free on purpose")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FOLDER || resultCode != RESULT_OK) return
        val tree = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        prefs.edit().putString("tree_uri", tree.toString()).apply()
        scanFolder(tree)
    }

    /** Lists .iso files directly inside the chosen folder. */
    private fun listIsos(tree: Uri): List<Pair<String, Uri>> {
        val out = ArrayList<Pair<String, Uri>>()
        val folderId = DocumentsContract.getTreeDocumentId(tree)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, folderId)
        try {
            contentResolver.query(
                children,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME
                ),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val name = c.getString(1) ?: continue
                    if (name.endsWith(".iso", ignoreCase = true)) {
                        out.add(name to DocumentsContract.buildDocumentUriUsingTree(tree, c.getString(0)))
                    }
                }
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun scanFolder(tree: Uri) {
        val isos = listIsos(tree)
        when {
            isos.isEmpty() -> {
                setVerified(null)
                status.text = "No .iso file found in that folder.\n\n$NO_ISO_MESSAGE"
            }
            isos.size == 1 -> tryDisc(isos[0].second)
            else -> {
                AlertDialog.Builder(this)
                    .setTitle("Which disc image?")
                    .setItems(isos.map { it.first }.toTypedArray()) { _, which -> tryDisc(isos[which].second) }
                    .show()
            }
        }
    }

    // ---- disc verification ----

    private fun verifyIso(uri: Uri): Pair<Boolean, String> {
        val known = File(filesDir, "known_builds.txt")
        assets.open("known_builds.txt").use { src -> known.outputStream().use { src.copyTo(it) } }

        val pfd = try {
            contentResolver.openFileDescriptor(uri, "r")
        } catch (_: Exception) {
            null
        } ?: return false to "Could not open the disc image. Pick the folder again."

        val result = pfd.use { NativeBridge.verifyDisc(it.fd, known.absolutePath) }
        return result.startsWith("OK") to result.substringAfter('|')
    }

    private fun tryDisc(iso: Uri) {
        val (ok, msg) = verifyIso(iso)
        if (ok) prefs.edit().putString("iso_uri", iso.toString()).apply()
        setVerified(if (ok) iso else null)
        status.text = msg
    }

    private fun setVerified(iso: Uri?) {
        verifiedIso = iso
        // Play stays tappable so that, with no disc, it can tell the player what to do.
        btnPlay.isEnabled = deviceOk
    }

    /** On later launches, reuse the saved folder/disc without asking again. */
    private fun restoreSavedDisc() {
        if (!deviceOk) return
        val saved = prefs.getString("iso_uri", null) ?: return
        val (ok, msg) = verifyIso(Uri.parse(saved))
        if (ok) {
            setVerified(Uri.parse(saved))
            status.text = "$msg\nSaved disc found."
        }
    }

    // ---- menu actions ----

    private fun onPlay() {
        val iso = verifiedIso
        if (iso == null) {
            status.text = NO_ISO_MESSAGE
            Toast.makeText(this, NO_ISO_MESSAGE, Toast.LENGTH_LONG).show()
            return
        }
        // The disc is read in place from the picked folder (SD card included); it is not copied.
        startActivity(Intent(this, PlayActivity::class.java).setData(iso))
    }

    private fun showCredit() {
        AlertDialog.Builder(this)
            .setTitle("Credit")
            .setMessage("@shady-z1f – YouTube+")
            .setPositiveButton("OK", null)
            .show()
    }

    companion object {
        private const val REQ_FOLDER = 1
        private const val NO_ISO_MESSAGE = "Add a PS2 cod3 iso cuhh"
    }
}

package com.cod3a

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt

/**
 * Game screen. The game engine is not built yet, so for now this is an input test screen:
 * it shows the pad state the game would receive from touch, keyboard/mouse or a controller.
 *
 * Keyboard/mouse defaults: WASD = move, mouse = look, left click = R2, right click = L2,
 * Space = Cross, C = Circle, R = Square, F = Triangle, Q = L1, E = R1, Shift = L3, V = R3,
 * Enter = Start, Tab = Select, arrows = D-pad, Esc = free the mouse (click to grab it again).
 */
class PlayActivity : Activity(), TouchControls.Listener {

    private lateinit var root: FrameLayout
    private lateinit var info: TextView
    private lateinit var overlay: TouchControls

    private val handler = Handler(Looper.getMainLooper())
    private val moveKeys = HashSet<Int>()
    private var mouseCaptured = false
    private var mouseFree = false  // set by Esc; cleared by the next mouse click

    private val releaseLook = Runnable { NativeBridge.padStick(Src.KBM, 1, 0f, 0f) }

    private val refresh = object : Runnable {
        override fun run() {
            info.text = HEADER + NativeBridge.padDescribe()
            handler.postDelayed(this, 100)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE

        root = FrameLayout(this).apply {
            setBackgroundColor(0xFF101418.toInt())
            isFocusable = true
            isFocusableInTouchMode = true
        }
        info = TextView(this).apply {
            setTextColor(0xFFDDDDDD.toInt())
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        root.addView(
            info,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        overlay = TouchControls(this).also { it.listener = this }
        root.addView(
            overlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        setContentView(root)

        if (Build.VERSION.SDK_INT >= 26) {
            root.setOnCapturedPointerListener { _, ev -> onCaptured(ev) }
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresh)
        handler.removeCallbacks(releaseLook)
        moveKeys.clear()
        overlay.releaseAll()
        NativeBridge.padReset()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    // ---- touch (on-screen controls) ----

    override fun onButton(mask: Int, down: Boolean) = NativeBridge.padButton(Src.TOUCH, mask, down)

    override fun onStick(stick: Int, x: Float, y: Float) = NativeBridge.padStick(Src.TOUCH, stick, x, y)

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // A mouse click grabs the mouse for looking around instead of acting like a finger.
        if (ev.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                mouseFree = false
                grabMouse()
            }
            return true
        }
        // A finger brings the on-screen controls back after a keyboard or controller hid them.
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && overlay.visibility != View.VISIBLE) {
            overlay.visibility = View.VISIBLE
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun hideOverlay() {
        if (overlay.visibility == View.VISIBLE) overlay.visibility = View.INVISIBLE
    }

    // ---- keyboard and controller buttons ----

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        val code = e.keyCode
        if (code == KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e)
        if (e.action != KeyEvent.ACTION_DOWN && e.action != KeyEvent.ACTION_UP) return super.dispatchKeyEvent(e)
        val down = e.action == KeyEvent.ACTION_DOWN

        if (code == KeyEvent.KEYCODE_ESCAPE) {
            if (!down) {
                mouseFree = true
                releaseMouse()
            }
            return true
        }

        val fromGamepad = (e.source and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (fromGamepad) {
            val mask = InputMapper.gamepadMask(code)
            if (mask != 0) {
                hideOverlay()
                NativeBridge.padButton(Src.GAMEPAD, mask, down)
                return true
            }
            return super.dispatchKeyEvent(e)
        }

        if (InputMapper.isMoveKey(code)) {
            hideOverlay()
            if (down) moveKeys.add(code) else moveKeys.remove(code)
            updateMoveStick()
            return true
        }
        val mask = InputMapper.keyboardMask(code)
        if (mask != 0) {
            hideOverlay()
            NativeBridge.padButton(Src.KBM, mask, down)
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    private fun updateMoveStick() {
        var x = 0f
        var y = 0f
        if (KeyEvent.KEYCODE_D in moveKeys) x += 1f
        if (KeyEvent.KEYCODE_A in moveKeys) x -= 1f
        if (KeyEvent.KEYCODE_S in moveKeys) y += 1f
        if (KeyEvent.KEYCODE_W in moveKeys) y -= 1f
        val len = sqrt(x * x + y * y)
        if (len > 1f) {
            x /= len
            y /= len
        }
        NativeBridge.padStick(Src.KBM, 0, x, y)
    }

    // ---- controller sticks, triggers and D-pad hat ----

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        val src = e.source
        if ((src and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            e.actionMasked == MotionEvent.ACTION_MOVE
        ) {
            handleJoystick(e)
            return true
        }
        if ((src and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE && !mouseCaptured && !mouseFree) {
            grabMouse()
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    private fun handleJoystick(e: MotionEvent) {
        val lx = e.getAxisValue(MotionEvent.AXIS_X)
        val ly = e.getAxisValue(MotionEvent.AXIS_Y)
        var rx = e.getAxisValue(MotionEvent.AXIS_Z)
        var ry = e.getAxisValue(MotionEvent.AXIS_RZ)
        if (abs(rx) + abs(ry) < 0.01f) {  // some controllers report the right stick as RX/RY
            rx = e.getAxisValue(MotionEvent.AXIS_RX)
            ry = e.getAxisValue(MotionEvent.AXIS_RY)
        }
        NativeBridge.padStick(Src.GAMEPAD, 0, lx, ly)
        NativeBridge.padStick(Src.GAMEPAD, 1, rx, ry)

        val l2 = max(e.getAxisValue(MotionEvent.AXIS_LTRIGGER), e.getAxisValue(MotionEvent.AXIS_BRAKE))
        val r2 = max(e.getAxisValue(MotionEvent.AXIS_RTRIGGER), e.getAxisValue(MotionEvent.AXIS_GAS))
        NativeBridge.padButton(Src.GAMEPAD, Pad.L2, l2 > 0.5f)
        NativeBridge.padButton(Src.GAMEPAD, Pad.R2, r2 > 0.5f)

        val hx = e.getAxisValue(MotionEvent.AXIS_HAT_X)
        val hy = e.getAxisValue(MotionEvent.AXIS_HAT_Y)
        NativeBridge.padButton(Src.GAMEPAD, Pad.LEFT, hx < -0.5f)
        NativeBridge.padButton(Src.GAMEPAD, Pad.RIGHT, hx > 0.5f)
        NativeBridge.padButton(Src.GAMEPAD, Pad.UP, hy < -0.5f)
        NativeBridge.padButton(Src.GAMEPAD, Pad.DOWN, hy > 0.5f)

        if (abs(lx) + abs(ly) > 0.5f || abs(rx) + abs(ry) > 0.5f || l2 > 0.5f || r2 > 0.5f) hideOverlay()
    }

    // ---- mouse (captured, so it can look around without hitting the screen edge) ----

    private fun grabMouse() {
        if (Build.VERSION.SDK_INT >= 26 && !mouseCaptured) {
            root.requestFocus()
            root.requestPointerCapture()
        }
    }

    private fun releaseMouse() {
        if (Build.VERSION.SDK_INT >= 26) root.releasePointerCapture()
    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {
        super.onPointerCaptureChanged(hasCapture)
        mouseCaptured = hasCapture
        if (!hasCapture) {
            NativeBridge.padButton(Src.KBM, Pad.R2 or Pad.L2, false)
            NativeBridge.padStick(Src.KBM, 1, 0f, 0f)
        }
    }

    private fun onCaptured(ev: MotionEvent): Boolean {
        hideOverlay()
        val buttons = ev.buttonState
        NativeBridge.padButton(Src.KBM, Pad.R2, (buttons and MotionEvent.BUTTON_PRIMARY) != 0)
        NativeBridge.padButton(Src.KBM, Pad.L2, (buttons and MotionEvent.BUTTON_SECONDARY) != 0)
        if (ev.actionMasked == MotionEvent.ACTION_MOVE) {
            // Captured pointers report relative movement; turn it into a short right-stick push.
            val x = (ev.x * LOOK_SENSITIVITY).coerceIn(-1f, 1f)
            val y = (ev.y * LOOK_SENSITIVITY).coerceIn(-1f, 1f)
            NativeBridge.padStick(Src.KBM, 1, x, y)
            handler.removeCallbacks(releaseLook)
            handler.postDelayed(releaseLook, 40)
        }
        return true
    }

    companion object {
        private const val LOOK_SENSITIVITY = 0.12f
        private const val HEADER = "INPUT TEST MODE\n" +
            "The game engine is not built yet, so the game can't start.\n" +
            "This is what the game would receive from your touch, keyboard/mouse or controller:\n\n"
    }
}

package com.cod3a

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.min

/**
 * On-screen controls for phones:
 *  - left side, anywhere empty: floating move stick (left stick)
 *  - right side, anywhere empty: floating look stick (right stick)
 *  - face buttons bottom-right, L1/L2 top-left, R1/R2 top-right, Start/Select top-center
 * Fully multitouch: every finger is tracked on its own.
 */
class TouchControls(context: Context) : View(context) {

    interface Listener {
        fun onButton(mask: Int, down: Boolean)
        fun onStick(stick: Int, x: Float, y: Float)
    }

    var listener: Listener? = null

    private class Btn(val label: String, val mask: Int) {
        var cx = 0f
        var cy = 0f
        var r = 0f
        var pressed = false
    }

    private val buttons = listOf(
        Btn("✕", Pad.CROSS),
        Btn("○", Pad.CIRCLE),
        Btn("□", Pad.SQUARE),
        Btn("△", Pad.TRIANGLE),
        Btn("L1", Pad.L1),
        Btn("L2", Pad.L2),
        Btn("R1", Pad.R1),
        Btn("R2", Pad.R2),
        Btn("START", Pad.START),
        Btn("SELECT", Pad.SELECT)
    )

    private class Stick(val index: Int) {
        var id = -1
        var startX = 0f
        var startY = 0f
        var x = 0f   // -1..1
        var y = 0f
    }

    private val move = Stick(0)
    private val look = Stick(1)

    // pointer id -> index in `buttons`, or ROLE_MOVE / ROLE_LOOK
    private val roles = HashMap<Int, Int>()

    private var stickRadius = 0f

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
        strokeWidth = 3f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val u = h / 100f
        stickRadius = 14f * u
        stroke.strokeWidth = 0.4f * u

        val fx = w - 24f * u
        val fy = h - 28f * u
        val off = 11f * u
        place("△", fx, fy - off, 7f * u)   // triangle
        place("✕", fx, fy + off, 7f * u)   // cross
        place("□", fx - off, fy, 7f * u)   // square
        place("○", fx + off, fy, 7f * u)   // circle

        place("L2", 9f * u, 9f * u, 6.5f * u)
        place("L1", 9f * u, 23f * u, 6.5f * u)
        place("R2", w - 9f * u, 9f * u, 6.5f * u)
        place("R1", w - 9f * u, 23f * u, 6.5f * u)

        place("SELECT", w / 2f - 11f * u, 7f * u, 5.5f * u)
        place("START", w / 2f + 11f * u, 7f * u, 5.5f * u)
    }

    private fun place(label: String, cx: Float, cy: Float, r: Float) {
        buttons.first { it.label == label }.apply {
            this.cx = cx
            this.cy = cy
            this.r = r
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                pointerDown(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until e.pointerCount) pointerMove(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> pointerUp(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        invalidate()
        return true
    }

    private fun pointerDown(id: Int, x: Float, y: Float) {
        val hit = buttons.indexOfFirst { hypot(x - it.cx, y - it.cy) <= it.r * 1.2f }
        if (hit >= 0) {
            roles[id] = hit
            buttons[hit].pressed = true
            listener?.onButton(buttons[hit].mask, true)
            return
        }
        val s = if (x < width * 0.45f) move else look
        if (s.id != -1) return  // that side already has a finger
        s.id = id
        s.startX = x
        s.startY = y
        s.x = 0f
        s.y = 0f
        roles[id] = if (s === move) ROLE_MOVE else ROLE_LOOK
    }

    private fun pointerMove(id: Int, x: Float, y: Float) {
        val s = when (roles[id]) {
            ROLE_MOVE -> move
            ROLE_LOOK -> look
            else -> return
        }
        var dx = (x - s.startX) / stickRadius
        var dy = (y - s.startY) / stickRadius
        val len = hypot(dx, dy)
        if (len > 1f) {
            dx /= len
            dy /= len
        }
        s.x = dx
        s.y = dy
        listener?.onStick(s.index, dx, dy)
    }

    private fun pointerUp(id: Int) {
        when (val role = roles.remove(id)) {
            null -> {}
            ROLE_MOVE -> endStick(move)
            ROLE_LOOK -> endStick(look)
            else -> {
                buttons[role].pressed = false
                listener?.onButton(buttons[role].mask, false)
            }
        }
    }

    private fun endStick(s: Stick) {
        s.id = -1
        s.x = 0f
        s.y = 0f
        listener?.onStick(s.index, 0f, 0f)
    }

    /** Lets go of everything (cancel, hiding the overlay, leaving the screen). */
    fun releaseAll() {
        roles.clear()
        for (b in buttons) {
            if (b.pressed) {
                b.pressed = false
                listener?.onButton(b.mask, false)
            }
        }
        if (move.id != -1) endStick(move)
        if (look.id != -1) endStick(look)
        invalidate()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility != VISIBLE) releaseAll()
    }

    override fun onDraw(c: Canvas) {
        for (b in buttons) {
            fill.color = Color.argb(if (b.pressed) 150 else 55, 255, 255, 255)
            c.drawCircle(b.cx, b.cy, b.r, fill)
            stroke.alpha = 160
            c.drawCircle(b.cx, b.cy, b.r, stroke)
            text.textSize = if (b.label.length > 2) b.r * 0.5f else b.r * 0.95f
            c.drawText(b.label, b.cx, b.cy + text.textSize * 0.35f, text)
        }
        for (s in listOf(move, look)) {
            if (s.id == -1) continue
            fill.color = Color.argb(40, 255, 255, 255)
            c.drawCircle(s.startX, s.startY, stickRadius, fill)
            stroke.alpha = 120
            c.drawCircle(s.startX, s.startY, stickRadius, stroke)
            fill.color = Color.argb(130, 255, 255, 255)
            c.drawCircle(s.startX + s.x * stickRadius, s.startY + s.y * stickRadius, stickRadius * 0.45f, fill)
        }
    }

    companion object {
        private const val ROLE_MOVE = -2
        private const val ROLE_LOOK = -3
    }
}

package com.cod3a

import android.view.KeyEvent

/** Bit values must match PadButton in runtime/input.h. */
object Pad {
    const val UP = 1 shl 0
    const val DOWN = 1 shl 1
    const val LEFT = 1 shl 2
    const val RIGHT = 1 shl 3
    const val CROSS = 1 shl 4
    const val CIRCLE = 1 shl 5
    const val SQUARE = 1 shl 6
    const val TRIANGLE = 1 shl 7
    const val L1 = 1 shl 8
    const val R1 = 1 shl 9
    const val L2 = 1 shl 10
    const val R2 = 1 shl 11
    const val L3 = 1 shl 12
    const val R3 = 1 shl 13
    const val START = 1 shl 14
    const val SELECT = 1 shl 15
}

/** Must match PadSource in runtime/input.h. */
object Src {
    const val TOUCH = 0
    const val KBM = 1
    const val GAMEPAD = 2
}

object InputMapper {

    /** Standard Android gamepad layout (Xbox / PlayStation / generic controllers). */
    fun gamepadMask(keyCode: Int): Int = when (keyCode) {
        KeyEvent.KEYCODE_BUTTON_A -> Pad.CROSS
        KeyEvent.KEYCODE_BUTTON_B -> Pad.CIRCLE
        KeyEvent.KEYCODE_BUTTON_X -> Pad.SQUARE
        KeyEvent.KEYCODE_BUTTON_Y -> Pad.TRIANGLE
        KeyEvent.KEYCODE_BUTTON_L1 -> Pad.L1
        KeyEvent.KEYCODE_BUTTON_R1 -> Pad.R1
        KeyEvent.KEYCODE_BUTTON_L2 -> Pad.L2
        KeyEvent.KEYCODE_BUTTON_R2 -> Pad.R2
        KeyEvent.KEYCODE_BUTTON_THUMBL -> Pad.L3
        KeyEvent.KEYCODE_BUTTON_THUMBR -> Pad.R3
        KeyEvent.KEYCODE_BUTTON_START -> Pad.START
        KeyEvent.KEYCODE_BUTTON_SELECT -> Pad.SELECT
        KeyEvent.KEYCODE_DPAD_UP -> Pad.UP
        KeyEvent.KEYCODE_DPAD_DOWN -> Pad.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Pad.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> Pad.RIGHT
        else -> 0
    }

    /**
     * Default keyboard layout. WASD (move) and the mouse (look, fire, aim) are handled in PlayActivity.
     * Mouse: left button = R2, right button = L2.
     */
    fun keyboardMask(keyCode: Int): Int = when (keyCode) {
        KeyEvent.KEYCODE_SPACE -> Pad.CROSS
        KeyEvent.KEYCODE_C -> Pad.CIRCLE
        KeyEvent.KEYCODE_R -> Pad.SQUARE
        KeyEvent.KEYCODE_F -> Pad.TRIANGLE
        KeyEvent.KEYCODE_Q -> Pad.L1
        KeyEvent.KEYCODE_E -> Pad.R1
        KeyEvent.KEYCODE_SHIFT_LEFT -> Pad.L3
        KeyEvent.KEYCODE_V -> Pad.R3
        KeyEvent.KEYCODE_ENTER -> Pad.START
        KeyEvent.KEYCODE_TAB -> Pad.SELECT
        KeyEvent.KEYCODE_DPAD_UP -> Pad.UP
        KeyEvent.KEYCODE_DPAD_DOWN -> Pad.DOWN
        KeyEvent.KEYCODE_DPAD_LEFT -> Pad.LEFT
        KeyEvent.KEYCODE_DPAD_RIGHT -> Pad.RIGHT
        else -> 0
    }

    fun isMoveKey(keyCode: Int): Boolean = keyCode == KeyEvent.KEYCODE_W ||
        keyCode == KeyEvent.KEYCODE_A || keyCode == KeyEvent.KEYCODE_S || keyCode == KeyEvent.KEYCODE_D
}

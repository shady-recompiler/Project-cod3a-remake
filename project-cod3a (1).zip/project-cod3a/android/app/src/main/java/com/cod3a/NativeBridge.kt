package com.cod3a

object NativeBridge {
    init {
        System.loadLibrary("cod3a_native")
    }

    /** Returns "TIER|reason" (Unsupported, Low, Medium, High). */
    external fun evaluateDevice(ramMB: Int, soc: String, glMajor: Int, glMinor: Int): String

    /** Returns "OK|message" or "FAIL|message". */
    external fun verifyDisc(fd: Int, knownBuildsPath: String): String

    // ---- pad input: touch, keyboard/mouse and gamepad each feed their own source ----

    /** source = Src.*, mask = Pad.* bit(s). */
    external fun padButton(source: Int, mask: Int, down: Boolean)

    /** stick 0 = left, 1 = right. x and y in -1..1, y positive = down. */
    external fun padStick(source: Int, stick: Int, x: Float, y: Float)

    external fun padReset()

    /** Human-readable snapshot of the merged pad state (used by the input test screen). */
    external fun padDescribe(): String
}

cmake_minimum_required(VERSION 3.18)
project(cod3a_native CXX)

set(CMAKE_CXX_STANDARD 17)
set(ROOT ${CMAKE_CURRENT_SOURCE_DIR}/../../../../..)

add_library(cod3a_native SHARED
  native_bridge.cpp
  ${ROOT}/core/iso_reader.cpp
  ${ROOT}/core/disc_verify.cpp
  ${ROOT}/core/elf_loader.cpp
  ${ROOT}/core/device_check.cpp
  ${ROOT}/recomp/mips_decode.cpp
  ${ROOT}/runtime/quality.cpp
  ${ROOT}/runtime/input.cpp
)
target_include_directories(cod3a_native PRIVATE ${ROOT})
target_link_libraries(cod3a_native log)

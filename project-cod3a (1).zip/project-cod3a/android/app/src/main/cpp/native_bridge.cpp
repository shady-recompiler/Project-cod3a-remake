#include <jni.h>

#include <string>

#include "core/device_check.h"
#include "core/disc_verify.h"
#include "core/iso_reader.h"
#include "runtime/input.h"

using namespace cod3a;

static PadInput gPad;  // shared pad state the game runtime will read from

static std::string toStd(JNIEnv* env, jstring s) {
    if (!s) return {};
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

// Returns "TIER|reason", where TIER is Unsupported, Low, Medium or High.
extern "C" JNIEXPORT jstring JNICALL
Java_com_cod3a_NativeBridge_evaluateDevice(JNIEnv* env, jobject, jint ramMB, jstring soc, jint glMajor, jint glMinor) {
    DeviceVerdict v = evaluateDevice({ramMB, toStd(env, soc), glMajor, glMinor});
    return env->NewStringUTF((std::string(tierName(v.tier)) + "|" + v.reason).c_str());
}

// Returns "OK|message" or "FAIL|message". `fd` comes from the document picker.
extern "C" JNIEXPORT jstring JNICALL
Java_com_cod3a_NativeBridge_verifyDisc(JNIEnv* env, jobject, jint fd, jstring knownBuildsPath) {
    IsoReader iso;
    if (!iso.openFd(fd)) {
        return env->NewStringUTF("FAIL|That file is not a readable PS2 disc image (.iso, 2048-byte sectors).");
    }
    auto known = loadKnownBuilds(toStd(env, knownBuildsPath));
    VerifyResult r = verifyDisc(iso, known);
    std::string out = (r.verdict == Verdict::Ok ? "OK|" : "FAIL|") + r.message;
    return env->NewStringUTF(out.c_str());
}

// ---- controller input (touch, keyboard/mouse and gamepad all feed one pad) ----

extern "C" JNIEXPORT void JNICALL
Java_com_cod3a_NativeBridge_padButton(JNIEnv*, jobject, jint source, jint mask, jboolean down) {
    gPad.setButton(source, static_cast<uint32_t>(mask), down == JNI_TRUE);
}

extern "C" JNIEXPORT void JNICALL
Java_com_cod3a_NativeBridge_padStick(JNIEnv*, jobject, jint source, jint stick, jfloat x, jfloat y) {
    gPad.setStick(source, stick, x, y);
}

extern "C" JNIEXPORT void JNICALL
Java_com_cod3a_NativeBridge_padReset(JNIEnv*, jobject) {
    gPad.reset();
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_cod3a_NativeBridge_padDescribe(JNIEnv* env, jobject) {
    return env->NewStringUTF(describePad(gPad.snapshot()).c_str());
}

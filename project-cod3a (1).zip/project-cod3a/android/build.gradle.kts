// Versions are reasonable guesses and have NOT been built here. If Android Studio offers
// to upgrade the Android Gradle Plugin or Kotlin, accept it.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}

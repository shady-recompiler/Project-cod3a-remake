cmake_minimum_required(VERSION 3.16)
project(cod3a CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(cod3a_core STATIC
  core/iso_reader.cpp
  core/disc_verify.cpp
  core/elf_loader.cpp
  core/device_check.cpp
  recomp/mips_decode.cpp
  runtime/quality.cpp
  runtime/input.cpp
)
target_include_directories(cod3a_core PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_compile_options(cod3a_core PRIVATE -Wall -Wextra)

add_executable(cod3a_tool tools/cod3a_tool.cpp)
target_link_libraries(cod3a_tool cod3a_core)

enable_testing()
add_executable(cod3a_tests tests/test_main.cpp)
target_link_libraries(cod3a_tests cod3a_core)
add_test(NAME cod3a_tests COMMAND cod3a_tests)

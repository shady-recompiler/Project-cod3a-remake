#pragma once
#include <cstdint>
#include <string>

namespace cod3a {

// First step of the recompiler: turn one MIPS instruction word into a line of C++.
// Only a few common instructions are handled so far; everything else is emitted as
// an `UNIMPLEMENTED` marker so gaps are visible in generated output.
//
// NOTE: the PS2's R5900 has 128-bit registers and many extensions (MMI, COP2/VU0).
// This stub only touches the low 64 bits (`.lo`) and none of the extensions yet.
std::string decodeToCpp(uint32_t insn, uint32_t pc);

}  // namespace cod3a

#include "recomp/mips_decode.h"

#include <cstdio>

namespace cod3a {

std::string decodeToCpp(uint32_t insn, uint32_t pc) {
    const uint32_t op = insn >> 26;
    const uint32_t rs = (insn >> 21) & 31;
    const uint32_t rt = (insn >> 16) & 31;
    const uint32_t rd = (insn >> 11) & 31;
    const uint32_t sa = (insn >> 6) & 31;
    const uint32_t fn = insn & 63;
    const int32_t imm = int16_t(insn & 0xFFFF);
    const uint32_t uimm = insn & 0xFFFF;
    const uint32_t target = (insn & 0x03FFFFFF) << 2;

    char b[160];
    switch (op) {
        case 0:
            switch (fn) {
                case 0x00:
                    if (insn == 0) return "/* nop */";
                    std::snprintf(b, sizeof b, "r[%u].lo = (int64_t)(int32_t)((uint32_t)r[%u].lo << %u);", rd, rt, sa);
                    return b;
                case 0x08:
                    std::snprintf(b, sizeof b, "return r[%u].lo; /* jr */", rs);
                    return b;
                case 0x21:
                    std::snprintf(b, sizeof b, "r[%u].lo = (int64_t)(int32_t)((uint32_t)r[%u].lo + (uint32_t)r[%u].lo);", rd, rs, rt);
                    return b;
                case 0x25:
                    std::snprintf(b, sizeof b, "r[%u].lo = r[%u].lo | r[%u].lo;", rd, rs, rt);
                    return b;
                default: break;
            }
            break;
        case 0x02:
            std::snprintf(b, sizeof b, "goto L_%08X; /* j */", (pc & 0xF0000000u) | target);
            return b;
        case 0x03:
            std::snprintf(b, sizeof b, "r[31].lo = 0x%08X; call_%08X(ctx); /* jal */", pc + 8, (pc & 0xF0000000u) | target);
            return b;
        case 0x09:
            std::snprintf(b, sizeof b, "r[%u].lo = (int64_t)(int32_t)((uint32_t)r[%u].lo + (int32_t)%d);", rt, rs, imm);
            return b;
        case 0x0D:
            std::snprintf(b, sizeof b, "r[%u].lo = r[%u].lo | 0x%04X;", rt, rs, uimm);
            return b;
        case 0x0F:
            std::snprintf(b, sizeof b, "r[%u].lo = (int64_t)(int32_t)(0x%04X << 16);", rt, uimm);
            return b;
        case 0x23:
            std::snprintf(b, sizeof b, "r[%u].lo = (int64_t)(int32_t)mem_read32(ctx, (uint32_t)r[%u].lo + (int32_t)%d);", rt, rs, imm);
            return b;
        case 0x2B:
            std::snprintf(b, sizeof b, "mem_write32(ctx, (uint32_t)r[%u].lo + (int32_t)%d, (uint32_t)r[%u].lo);", rs, imm, rt);
            return b;
        default: break;
    }
    std::snprintf(b, sizeof b, "UNIMPLEMENTED(0x%08X); /* at 0x%08X */", insn, pc);
    return b;
}

}  // namespace cod3a

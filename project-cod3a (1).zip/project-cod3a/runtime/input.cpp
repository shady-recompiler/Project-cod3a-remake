#include "runtime/input.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace cod3a {

void PadInput::setButton(int source, uint32_t mask, bool down) {
    if (source < 0 || source >= SRC_COUNT) return;
    std::lock_guard<std::mutex> g(m_);
    if (down) buttons_[source] |= mask;
    else buttons_[source] &= ~mask;
}

void PadInput::setStick(int source, int stick, float x, float y) {
    if (source < 0 || source >= SRC_COUNT || stick < 0 || stick > 1) return;
    std::lock_guard<std::mutex> g(m_);
    stick_[source][stick][0] = x;
    stick_[source][stick][1] = y;
}

void PadInput::reset() {
    std::lock_guard<std::mutex> g(m_);
    for (int s = 0; s < SRC_COUNT; ++s) {
        buttons_[s] = 0;
        for (int k = 0; k < 2; ++k) stick_[s][k][0] = stick_[s][k][1] = 0.f;
    }
}

uint8_t PadInput::axisToByte(float v) {
    v = std::max(-1.f, std::min(1.f, v));
    int b = int(std::lround(128.0f + v * 127.5f));
    return uint8_t(std::max(0, std::min(255, b)));
}

void PadInput::applyDeadzone(float& x, float& y, float dz) {
    float m = std::sqrt(x * x + y * y);
    if (m < dz) { x = y = 0.f; return; }
    float scaled = (std::min(m, 1.f) - dz) / (1.f - dz);
    x = x / m * scaled;
    y = y / m * scaled;
}

PadState PadInput::snapshot() const {
    std::lock_guard<std::mutex> g(m_);
    PadState out;
    for (int s = 0; s < SRC_COUNT; ++s) out.buttons |= buttons_[s];

    uint8_t* dst[2][2] = {{&out.lx, &out.ly}, {&out.rx, &out.ry}};
    for (int k = 0; k < 2; ++k) {
        float bx = 0.f, by = 0.f, best = -1.f;
        for (int s = 0; s < SRC_COUNT; ++s) {
            float x = stick_[s][k][0], y = stick_[s][k][1];
            applyDeadzone(x, y);
            float m = x * x + y * y;
            if (m > best) { best = m; bx = x; by = y; }
        }
        *dst[k][0] = axisToByte(bx);
        *dst[k][1] = axisToByte(by);
    }
    return out;
}

std::string describePad(const PadState& s) {
    static const struct { uint32_t bit; const char* name; } names[] = {
        {PAD_UP, "Up"}, {PAD_DOWN, "Down"}, {PAD_LEFT, "Left"}, {PAD_RIGHT, "Right"},
        {PAD_CROSS, "Cross"}, {PAD_CIRCLE, "Circle"}, {PAD_SQUARE, "Square"}, {PAD_TRIANGLE, "Triangle"},
        {PAD_L1, "L1"}, {PAD_R1, "R1"}, {PAD_L2, "L2"}, {PAD_R2, "R2"},
        {PAD_L3, "L3"}, {PAD_R3, "R3"}, {PAD_START, "Start"}, {PAD_SELECT, "Select"},
    };
    std::string out = "Buttons: ";
    bool any = false;
    for (const auto& n : names) {
        if (s.buttons & n.bit) {
            if (any) out += " ";
            out += n.name;
            any = true;
        }
    }
    if (!any) out += "none";
    char b[96];
    std::snprintf(b, sizeof b, "\nLeft stick: %d,%d   Right stick: %d,%d", s.lx, s.ly, s.rx, s.ry);
    return out + b;
}

}  // namespace cod3a

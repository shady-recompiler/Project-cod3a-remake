#pragma once
#include <cstdint>

#include "core/device_check.h"

namespace cod3a {

struct QualitySettings {
    float resolutionScale;  // 1.0 = the game's native output size
    int fpsCap;
    bool postEffects;
    bool reducedAudioChannels;
};

QualitySettings settingsForTier(Tier t);

// Graphics backend interface. The GLES 3.0 backend is the baseline (many low-end phones have
// weak Vulkan drivers); a Vulkan backend can be added behind the same interface later.
class IRenderer {
public:
    virtual ~IRenderer() = default;
    virtual bool init(void* nativeWindow, const QualitySettings& q) = 0;
    virtual void beginFrame() = 0;
    virtual void endFrame() = 0;
    virtual void shutdown() = 0;
};

}  // namespace cod3a

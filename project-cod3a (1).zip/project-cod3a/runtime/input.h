#pragma once
#include <cstdint>
#include <mutex>
#include <string>

namespace cod3a {

// Bit values must match `object Pad` in android/.../InputMapper.kt.
enum PadButton : uint32_t {
    PAD_UP = 1u << 0,
    PAD_DOWN = 1u << 1,
    PAD_LEFT = 1u << 2,
    PAD_RIGHT = 1u << 3,
    PAD_CROSS = 1u << 4,
    PAD_CIRCLE = 1u << 5,
    PAD_SQUARE = 1u << 6,
    PAD_TRIANGLE = 1u << 7,
    PAD_L1 = 1u << 8,
    PAD_R1 = 1u << 9,
    PAD_L2 = 1u << 10,
    PAD_R2 = 1u << 11,
    PAD_L3 = 1u << 12,
    PAD_R3 = 1u << 13,
    PAD_START = 1u << 14,
    PAD_SELECT = 1u << 15,
};

// Input sources. Each keeps its own state so they don't fight each other.
enum PadSource : int { SRC_TOUCH = 0, SRC_KBM = 1, SRC_GAMEPAD = 2, SRC_COUNT = 3 };

// What the game would read from a PS2 DualShock: 0..255 sticks, 128 = centered, y grows downward.
struct PadState {
    uint32_t buttons = 0;
    uint8_t lx = 128, ly = 128, rx = 128, ry = 128;
};

class PadInput {
public:
    void setButton(int source, uint32_t mask, bool down);
    // stick: 0 = left, 1 = right. x/y in -1..1, y positive = down.
    void setStick(int source, int stick, float x, float y);
    void reset();
    // Buttons from all sources are OR'd; for each stick the source pushed furthest wins.
    PadState snapshot() const;

    static uint8_t axisToByte(float v);
    // Radial dead zone with rescaling, so small drift reads as exactly centered.
    static void applyDeadzone(float& x, float& y, float deadzone = 0.12f);

private:
    mutable std::mutex m_;
    uint32_t buttons_[SRC_COUNT] = {};
    float stick_[SRC_COUNT][2][2] = {};
};

std::string describePad(const PadState& s);

}  // namespace cod3a

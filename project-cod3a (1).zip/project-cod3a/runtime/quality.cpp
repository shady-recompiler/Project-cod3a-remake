#include "runtime/renderer.h"

namespace cod3a {

QualitySettings settingsForTier(Tier t) {
    switch (t) {
        case Tier::High:   return {1.0f, 60, true, false};
        case Tier::Medium: return {0.75f, 30, true, false};
        case Tier::Low:    return {0.5f, 30, false, true};
        default:           return {0.5f, 30, false, true};
    }
}

}  // namespace cod3a

# Project cod3a

A native Android port project for **Call of Duty 3 (PS2, USA / NTSC-U)**, in the spirit of static-recompilation ports.
It is **not an emulator wrapper**: the plan is to translate the game's own code to native ARM64 and run it on a small custom runtime, so that low-end phones can handle it.

## Legal / anti-piracy model

- This repository contains **no game code, no textures, no audio, no video**, and no converted game code.
- Users must supply **their own legally dumped USA PS2 disc image** (`.iso`, 2048-byte sectors).
- The app verifies the disc (serial from `SYSTEM.CNF`, region check, CRC32 of the main executable) and refuses anything else.
- Recompilation happens **on the user's device** on first launch, and the output stays in the app's private storage. Only the tools are distributed, never converted game code.
- Do not link to or name sources for disc images anywhere in this project.
- The app cannot prove how a disc was obtained; the README and the import screen must say users need to dump their own disc.

## Minimum device spec (heuristic, see `core/device_check.cpp`)

| Requirement | Minimum |
|---|---|
| RAM | 3 GB (phones report about 2.7+ GB) |
| Chip | Snapdragon 6xx or higher, or MediaTek Helio P35 (as in the Oppo A12) or better |
| GPU | OpenGL ES 3.0 |

Quality tiers (Low / Medium / High) are picked from the detected chip and RAM. Low = reduced resolution, 30 fps cap, trimmed effects.

## Layout

```
core/       ISO9660 reader, disc verification, ELF loader, device check
recomp/     MIPS R5900 decoder stub (first step toward the recompiler)
runtime/    Renderer interface and quality settings
tools/      cod3a_tool: identify a disc, inspect its ELF
tests/      Unit tests (use a synthetic fake disc, no game data)
android/    Android Studio (NDK) shell: device check + ISO picker + JNI bridge (UNTESTED)
data/       known_builds.txt (empty until you fill it from your own disc)
```

## Build and test (desktop)

```
cmake -S . -B build && cmake --build build && ./build/cod3a_tests
./build/cod3a_tool identify path/to/your_disc.iso
```

## Getting the known-build entry

`data/known_builds.txt` ships empty on purpose, because the real serial and checksum must come from a real dump. With your own disc:

```
./build/cod3a_tool identify your_disc.iso
```

It prints the serial and CRC32 of the main executable. Add a line `SERIAL CRC32` to `data/known_builds.txt`.

## Status

| Piece | State |
|---|---|
| ISO reader, disc verification | Written and unit tested on a synthetic disc |
| ELF loader | Written and unit tested |
| MIPS decoder | Stub (a handful of instructions) |
| Recompiler, VU handling, GS renderer, audio, runtime | Not started (these are the large parts) |
| Android shell | Written, not built or tested |

## To do (known gaps)

- Read game assets directly from the ISO (no copy); the menu already picks the folder (SD card works) and remembers it. Optional: a "copy ISO into app storage" setting for faster reads.
- Recompiler, VU0/VU1 handling, GS-to-GLES renderer, SPU2 audio, IOP/file-system runtime.
- Fill `data/known_builds.txt` from your own disc with `cod3a_tool identify`.

## Building the APK without a PC (GitHub Actions)

1. Create a free GitHub account and a new repository.
2. Upload this project's files to it (keep the folder structure, including `.github/workflows/build-apk.yml`).
3. Open the repository's **Actions** tab, pick **Build APK**, and press **Run workflow**.
4. When it finishes (about 5-10 minutes), open the run and download the **project-cod3a-debug-apk** artifact, then unzip it and install the `.apk` (allow "install unknown apps" for your browser or Files app).

This workflow has not been run yet, so the first build may need small fixes.

## Controls

The Play button opens an **input test screen** for now (the game engine is not built yet). It shows exactly what the game would receive.

| Input | Default mapping |
|---|---|
| Touch | Left side drag = move, right side drag = look, on-screen face buttons, L1/L2/R1/R2, Start/Select. Multitouch. Hides itself while you use a keyboard or controller and returns when you touch the screen. |
| Controller | Any Android gamepad (Xbox, PlayStation, generic, Bluetooth or USB): sticks, triggers, D-pad, A/B/X/Y, bumpers, stick clicks, Start/Select. |
| Keyboard + mouse | WASD move, mouse look (captured), left click = R2, right click = L2, Space = Cross, C = Circle, R = Square, F = Triangle, Q = L1, E = R1, Shift = L3, V = R3, Enter = Start, Tab = Select, arrows = D-pad. Esc frees the mouse; click to grab it again. |

These are generic defaults, not Call of Duty 3's own layout. Remapping is not built yet.
The "Add a PS2 cod3 iso cuhh" message shows when no disc image has been added.

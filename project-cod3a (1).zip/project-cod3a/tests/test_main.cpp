// Unit tests. They use a synthetic fake disc built in memory: no game data is involved.
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

#include "core/device_check.h"
#include "core/disc_verify.h"
#include "core/elf_loader.h"
#include "core/iso_reader.h"
#include "recomp/mips_decode.h"
#include "runtime/input.h"
#include "runtime/renderer.h"

using namespace cod3a;

static int failures = 0;
#define CHECK(cond)                                                          \
    do {                                                                     \
        if (!(cond)) {                                                       \
            std::printf("FAIL line %d: %s\n", __LINE__, #cond);              \
            ++failures;                                                      \
        }                                                                    \
    } while (0)

static void put32(std::vector<uint8_t>& b, size_t off, uint32_t v) {
    for (int i = 0; i < 4; ++i) b[off + i] = uint8_t(v >> (8 * i));
}

// Writes one ISO9660 directory record, returns its length.
static size_t addRecord(std::vector<uint8_t>& img, size_t off, const std::string& name, uint32_t lba, uint32_t size, bool dir) {
    size_t len = 33 + name.size();
    if (len & 1) ++len;
    img[off] = uint8_t(len);
    put32(img, off + 2, lba);
    put32(img, off + 10, size);
    img[off + 25] = dir ? 2 : 0;
    img[off + 32] = uint8_t(name.size());
    std::memcpy(&img[off + 33], name.data(), name.size());
    return len;
}

static std::vector<uint8_t> makeElf() {
    std::vector<uint8_t> e(0x100, 0);
    std::memcpy(e.data(), "\x7f" "ELF", 4);
    e[4] = 1; e[5] = 1; e[6] = 1;
    e[18] = 8;                 // EM_MIPS
    put32(e, 24, 0x00100008);  // entry
    put32(e, 28, 52);          // phoff
    e[42] = 32; e[44] = 1;     // phentsize, phnum
    put32(e, 52 + 0, 1);       // PT_LOAD
    put32(e, 52 + 4, 0x80);    // offset
    put32(e, 52 + 8, 0x00100000);
    put32(e, 52 + 16, 0x80);   // filesz
    put32(e, 52 + 20, 0x100);  // memsz
    put32(e, 52 + 24, 5);      // R+X
    for (int i = 0x80; i < 0x100; ++i) e[i] = uint8_t(i);
    return e;
}

// bootName: e.g. "SLUS_999.99" (fake serial on purpose). withCnf=false leaves out SYSTEM.CNF.
static std::string makeDisc(const std::string& path, const std::string& bootName, bool withCnf) {
    std::vector<uint8_t> img(32 * 2048, 0);
    uint8_t* pvd = &img[16 * 2048];
    pvd[0] = 1;
    std::memcpy(pvd + 1, "CD001", 5);
    pvd[6] = 1;
    addRecord(img, 16 * 2048 + 156, "\0", 18, 2048, true);
    img[16 * 2048 + 156 + 32] = 1;

    std::string cnf = "BOOT2 = cdrom0:\\" + bootName + ";1\r\nVER = 1.00\r\nVMODE = NTSC\r\n";
    std::vector<uint8_t> elf = makeElf();

    size_t off = 18 * 2048;
    off += addRecord(img, off, std::string(1, '\0'), 18, 2048, true);
    off += addRecord(img, off, std::string(1, '\1'), 18, 2048, true);
    if (withCnf) off += addRecord(img, off, "SYSTEM.CNF;1", 19, uint32_t(cnf.size()), false);
    off += addRecord(img, off, bootName + ";1", 20, uint32_t(elf.size()), false);

    std::memcpy(&img[19 * 2048], cnf.data(), cnf.size());
    std::memcpy(&img[20 * 2048], elf.data(), elf.size());

    FILE* f = std::fopen(path.c_str(), "wb");
    std::fwrite(img.data(), 1, img.size(), f);
    std::fclose(f);
    return path;
}

static uint32_t elfCrc() {
    auto e = makeElf();
    return crc32(e.data(), e.size());
}

static void testCrc() {
    const char* s = "123456789";
    CHECK(crc32(reinterpret_cast<const uint8_t*>(s), 9) == 0xCBF43926u);
}

static void testParsing() {
    std::string elf;
    CHECK(parseBootLine("BOOT2 = cdrom0:\\SLUS_999.99;1\r\n", elf));
    CHECK(elf == "SLUS_999.99");
    CHECK(serialFromElfName(elf) == "SLUS-99999");
    CHECK(regionFromSerial("SLUS-99999") == "NTSC-U");
    CHECK(regionFromSerial("SLES-12345") == "PAL");
    CHECK(regionFromSerial("SLPM-12345") == "NTSC-J");
    CHECK(!parseBootLine("VER = 1.00", elf));
}

static void testDisc() {
    std::string p = "/tmp/cod3a_fake.iso";
    makeDisc(p, "SLUS_999.99", true);
    IsoReader iso;
    CHECK(iso.open(p));

    std::vector<KnownBuild> good = {{"SLUS-99999", elfCrc()}};
    VerifyResult r = verifyDisc(iso, good);
    CHECK(r.verdict == Verdict::Ok);
    CHECK(r.serial == "SLUS-99999");
    CHECK(r.elfCrc32 == elfCrc());

    CHECK(verifyDisc(iso, {}).verdict == Verdict::UnknownBuild);
    CHECK(verifyDisc(iso, {{"SLUS-99999", elfCrc() ^ 1}}).verdict == Verdict::UnknownBuild);

    // Region lock
    makeDisc(p, "SLES_999.99", true);
    IsoReader pal;
    CHECK(pal.open(p));
    CHECK(verifyDisc(pal, {{"SLES-99999", elfCrc()}}).verdict == Verdict::WrongRegion);

    // Not a PS2 disc
    makeDisc(p, "SLUS_999.99", false);
    IsoReader nocnf;
    CHECK(nocnf.open(p));
    CHECK(verifyDisc(nocnf, good).verdict == Verdict::NotPs2Disc);

    // Garbage file is not an ISO at all
    FILE* f = std::fopen(p.c_str(), "wb");
    std::vector<uint8_t> junk(40 * 2048, 0x55);
    std::fwrite(junk.data(), 1, junk.size(), f);
    std::fclose(f);
    IsoReader bad;
    CHECK(!bad.open(p));
    std::remove(p.c_str());
}

static void testElf() {
    ElfInfo info;
    std::string err;
    CHECK(parseElf(makeElf(), info, err));
    CHECK(info.entry == 0x00100008u);
    CHECK(info.loadSegments.size() == 1);
    CHECK(info.loadSegments[0].vaddr == 0x00100000u);

    std::vector<uint8_t> bad(64, 0);
    CHECK(!parseElf(bad, info, err));
    auto x86 = makeElf();
    x86[18] = 62;
    CHECK(!parseElf(x86, info, err));
}

static void testDevice() {
    // Oppo A12 class: Helio P35 (MT6765), 3 GB
    DeviceVerdict a12 = evaluateDevice({2900, "MT6765", 3, 2});
    CHECK(a12.tier == Tier::Low);
    // Snapdragon 660, 4 GB
    CHECK(evaluateDevice({3900, "SDM660", 3, 2}).tier == Tier::Low);
    // Snapdragon 730 with 6 GB
    CHECK(evaluateDevice({5900, "Snapdragon 730", 3, 2}).tier == Tier::Medium);
    // Snapdragon 865, 8 GB
    CHECK(evaluateDevice({7800, "SM8250", 3, 2}).tier == Tier::High);
    // Too little RAM
    CHECK(evaluateDevice({2000, "SDM660", 3, 2}).tier == Tier::Unsupported);
    // Weak chips
    CHECK(evaluateDevice({3900, "Snapdragon 450", 3, 0}).tier == Tier::Unsupported);
    CHECK(evaluateDevice({3900, "MT6739", 3, 0}).tier == Tier::Unsupported);
    // No GLES 3
    CHECK(evaluateDevice({3900, "SDM660", 2, 0}).tier == Tier::Unsupported);
    // Unknown chip: only with lots of RAM, and capped at Low
    CHECK(evaluateDevice({2900, "mystery", 3, 2}).tier == Tier::Unsupported);
    CHECK(evaluateDevice({7800, "mystery", 3, 2}).tier == Tier::Low);

    CHECK(settingsForTier(Tier::Low).fpsCap == 30);
    CHECK(settingsForTier(Tier::Low).resolutionScale < 1.0f);
}

static void testInput() {
    PadInput pad;
    PadState s = pad.snapshot();
    CHECK(s.buttons == 0);
    CHECK(s.lx == 128 && s.ly == 128 && s.rx == 128 && s.ry == 128);

    // Buttons from different sources are merged; releasing one keeps the other held.
    pad.setButton(SRC_TOUCH, PAD_CROSS, true);
    pad.setButton(SRC_GAMEPAD, PAD_CROSS, true);
    pad.setButton(SRC_KBM, PAD_R2, true);
    CHECK((pad.snapshot().buttons & PAD_CROSS) && (pad.snapshot().buttons & PAD_R2));
    pad.setButton(SRC_TOUCH, PAD_CROSS, false);
    CHECK(pad.snapshot().buttons & PAD_CROSS);
    pad.setButton(SRC_GAMEPAD, PAD_CROSS, false);
    CHECK(!(pad.snapshot().buttons & PAD_CROSS));

    // Dead zone: drift reads as centered, full deflection reaches the ends.
    pad.reset();
    pad.setStick(SRC_GAMEPAD, 0, 0.05f, -0.05f);
    s = pad.snapshot();
    CHECK(s.lx == 128 && s.ly == 128);
    pad.setStick(SRC_GAMEPAD, 0, 1.0f, 0.0f);
    CHECK(pad.snapshot().lx == 255);
    pad.setStick(SRC_GAMEPAD, 0, -1.0f, 0.0f);
    CHECK(pad.snapshot().lx <= 1);
    pad.setStick(SRC_GAMEPAD, 0, 0.0f, 1.0f);   // y positive = down = high byte
    CHECK(pad.snapshot().ly == 255);

    // The source pushed furthest wins a stick.
    pad.reset();
    pad.setStick(SRC_KBM, 0, 1.0f, 0.0f);
    pad.setStick(SRC_TOUCH, 0, -0.4f, 0.0f);
    CHECK(pad.snapshot().lx == 255);

    // Left and right sticks are independent.
    pad.reset();
    pad.setStick(SRC_TOUCH, 1, 0.0f, -1.0f);
    s = pad.snapshot();
    CHECK(s.lx == 128 && s.ly == 128 && s.rx == 128 && s.ry <= 1);

    // Invalid arguments are ignored rather than crashing.
    pad.setButton(99, PAD_UP, true);
    pad.setStick(0, 5, 1.f, 1.f);
    CHECK(pad.snapshot().buttons == 0);

    pad.setButton(SRC_TOUCH, PAD_L1 | PAD_START, true);
    std::string d = describePad(pad.snapshot());
    CHECK(d.find("L1") != std::string::npos && d.find("Start") != std::string::npos);
}

static void testDecode() {
    CHECK(decodeToCpp(0, 0) == "/* nop */");
    CHECK(decodeToCpp(0x3C041234, 0).find("0x1234") != std::string::npos);                    // lui
    CHECK(decodeToCpp(0x03E00008, 0).find("jr") != std::string::npos);                        // jr ra
    CHECK(decodeToCpp(0x70000000, 0x100).find("UNIMPLEMENTED") != std::string::npos);         // MMI
}

int main() {
    testCrc();
    testParsing();
    testDisc();
    testElf();
    testDevice();
    testDecode();
    testInput();
    if (failures == 0) std::printf("All tests passed.\n");
    return failures == 0 ? 0 : 1;
}

#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace cod3a {

class IsoReader;

struct KnownBuild {
    std::string serial;  // e.g. "SLUS-12345"
    uint32_t elfCrc32;
};

enum class Verdict { Ok, Unreadable, NotPs2Disc, WrongRegion, UnknownBuild };

struct VerifyResult {
    Verdict verdict = Verdict::Unreadable;
    std::string serial;
    std::string region;
    std::string elfName;
    uint32_t elfCrc32 = 0;
    std::string message;  // user-facing explanation
};

uint32_t crc32(const uint8_t* data, size_t n, uint32_t seed = 0);

// "SLUS_999.99" -> "SLUS-99999"
std::string serialFromElfName(const std::string& elfName);
// "SLUS-99999" -> "NTSC-U" / "PAL" / "NTSC-J" / "unknown"
std::string regionFromSerial(const std::string& serial);
// Finds the BOOT2 line in SYSTEM.CNF and extracts the executable name.
bool parseBootLine(const std::string& systemCnf, std::string& elfName);

// File format: "SERIAL CRC32HEX" per line, '#' starts a comment.
std::vector<KnownBuild> loadKnownBuilds(const std::string& path);

// Only a USA (NTSC-U) disc whose serial and executable checksum are listed is accepted.
VerifyResult verifyDisc(IsoReader& iso, const std::vector<KnownBuild>& known);

}  // namespace cod3a

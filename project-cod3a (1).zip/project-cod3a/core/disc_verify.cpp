#include "core/disc_verify.h"

#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>

#include "core/iso_reader.h"

namespace cod3a {

uint32_t crc32(const uint8_t* data, size_t n, uint32_t seed) {
    static uint32_t table[256];
    static bool ready = false;
    if (!ready) {
        for (uint32_t i = 0; i < 256; ++i) {
            uint32_t c = i;
            for (int k = 0; k < 8; ++k) c = (c & 1) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
            table[i] = c;
        }
        ready = true;
    }
    uint32_t c = ~seed;
    for (size_t i = 0; i < n; ++i) c = table[(c ^ data[i]) & 0xFF] ^ (c >> 8);
    return ~c;
}

std::string serialFromElfName(const std::string& elfName) {
    std::string s;
    for (char c : elfName) {
        if (c == '.') continue;
        s += (c == '_') ? '-' : char(std::toupper(static_cast<unsigned char>(c)));
    }
    return s;
}

std::string regionFromSerial(const std::string& serial) {
    if (serial.size() < 4) return "unknown";
    std::string p = serial.substr(0, 4);
    if (p == "SLUS" || p == "SCUS") return "NTSC-U";
    if (p == "SLES" || p == "SCES") return "PAL";
    if (p == "SLPM" || p == "SLPS" || p == "SCPS" || p == "SCAJ") return "NTSC-J";
    return "unknown";
}

bool parseBootLine(const std::string& cnf, std::string& elfName) {
    size_t b = cnf.find("BOOT2");
    if (b == std::string::npos) return false;
    size_t c = cnf.find("cdrom0:", b);
    if (c == std::string::npos) return false;
    size_t i = c + 7;
    while (i < cnf.size() && (cnf[i] == '\\' || cnf[i] == '/' || cnf[i] == ' ')) ++i;
    size_t j = i;
    while (j < cnf.size() && cnf[j] != ';' && cnf[j] != '\r' && cnf[j] != '\n' && cnf[j] != ' ') ++j;
    if (j <= i) return false;
    elfName = cnf.substr(i, j - i);
    return true;
}

std::vector<KnownBuild> loadKnownBuilds(const std::string& path) {
    std::vector<KnownBuild> out;
    std::ifstream f(path);
    std::string line;
    while (std::getline(f, line)) {
        size_t h = line.find('#');
        if (h != std::string::npos) line.resize(h);
        std::istringstream ss(line);
        std::string serial, crc;
        if (!(ss >> serial >> crc)) continue;
        for (auto& c : serial) c = char(std::toupper(static_cast<unsigned char>(c)));
        out.push_back({serial, uint32_t(std::strtoul(crc.c_str(), nullptr, 16))});
    }
    return out;
}

VerifyResult verifyDisc(IsoReader& iso, const std::vector<KnownBuild>& known) {
    VerifyResult r;

    IsoEntry cnfEntry;
    if (!iso.find("SYSTEM.CNF", cnfEntry)) {
        r.verdict = Verdict::NotPs2Disc;
        r.message = "This does not look like a PS2 game disc image (no SYSTEM.CNF).";
        return r;
    }
    std::vector<uint8_t> cnfData;
    if (!iso.read(cnfEntry, cnfData, 64 * 1024)) {
        r.verdict = Verdict::Unreadable;
        r.message = "Could not read the disc image.";
        return r;
    }
    if (!parseBootLine(std::string(cnfData.begin(), cnfData.end()), r.elfName)) {
        r.verdict = Verdict::NotPs2Disc;
        r.message = "SYSTEM.CNF has no PS2 boot entry.";
        return r;
    }

    r.serial = serialFromElfName(r.elfName);
    r.region = regionFromSerial(r.serial);
    if (r.region != "NTSC-U") {
        r.verdict = Verdict::WrongRegion;
        r.message = "Only the USA (NTSC-U) disc is supported. This disc is: " + r.region + " (" + r.serial + ").";
        return r;
    }

    IsoEntry elfEntry;
    std::vector<uint8_t> elf;
    if (!iso.find(r.elfName, elfEntry) || !iso.read(elfEntry, elf)) {
        r.verdict = Verdict::Unreadable;
        r.message = "Could not read the game's main executable from the disc.";
        return r;
    }
    r.elfCrc32 = crc32(elf.data(), elf.size());

    for (const auto& k : known) {
        if (k.serial == r.serial && k.elfCrc32 == r.elfCrc32) {
            r.verdict = Verdict::Ok;
            r.message = "Disc verified (" + r.serial + ").";
            return r;
        }
    }
    r.verdict = Verdict::UnknownBuild;
    r.message = "This disc (" + r.serial + ") is not a known supported build. It may be a bad dump or a different release.";
    return r;
}

}  // namespace cod3a

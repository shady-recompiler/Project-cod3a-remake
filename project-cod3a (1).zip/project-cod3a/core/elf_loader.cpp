#include "core/elf_loader.h"

#include <cstring>

namespace cod3a {

static uint32_t rd32(const uint8_t* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}
static uint16_t rd16(const uint8_t* p) { return uint16_t(p[0] | (p[1] << 8)); }

bool parseElf(const std::vector<uint8_t>& d, ElfInfo& out, std::string& err) {
    if (d.size() < 52 || std::memcmp(d.data(), "\x7f" "ELF", 4) != 0) { err = "not an ELF file"; return false; }
    if (d[4] != 1) { err = "not a 32-bit ELF"; return false; }
    if (d[5] != 1) { err = "not little-endian"; return false; }
    if (rd16(&d[18]) != 8) { err = "not a MIPS ELF"; return false; }

    out = ElfInfo{};
    out.entry = rd32(&d[24]);
    uint32_t phoff = rd32(&d[28]);
    uint16_t phentsize = rd16(&d[42]);
    uint16_t phnum = rd16(&d[44]);
    if (phentsize < 32 || phnum > 64) { err = "bad program header table"; return false; }
    if (uint64_t(phoff) + uint64_t(phnum) * phentsize > d.size()) { err = "program headers outside file"; return false; }

    for (uint16_t i = 0; i < phnum; ++i) {
        const uint8_t* ph = &d[phoff + size_t(i) * phentsize];
        if (rd32(ph) != 1) continue;  // PT_LOAD only
        ElfSegment s;
        s.offset = rd32(ph + 4);
        s.vaddr = rd32(ph + 8);
        s.fileSize = rd32(ph + 16);
        s.memSize = rd32(ph + 20);
        s.flags = rd32(ph + 24);
        if (uint64_t(s.offset) + s.fileSize > d.size()) { err = "segment outside file"; return false; }
        out.loadSegments.push_back(s);
    }
    if (out.loadSegments.empty()) { err = "no loadable segments"; return false; }
    return true;
}

}  // namespace cod3a

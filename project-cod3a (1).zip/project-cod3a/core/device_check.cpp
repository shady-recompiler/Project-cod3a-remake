#include "core/device_check.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>

namespace cod3a {

namespace {

constexpr int kMinRamMB = 2700;  // "3 GB" phones usually report about 2.7-2.9 GB

std::string lower(std::string s) {
    for (auto& c : s) c = char(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

// Returns the first run of digits found after `key`, or -1.
int numberAfter(const std::string& s, const std::string& key) {
    size_t p = s.find(key);
    if (p == std::string::npos) return -1;
    p += key.size();
    while (p < s.size() && !std::isdigit(static_cast<unsigned char>(s[p]))) {
        if (s[p] != ' ' && s[p] != '-' && s[p] != '_') return -1;
        ++p;
    }
    size_t q = p;
    while (q < s.size() && std::isdigit(static_cast<unsigned char>(s[q]))) ++q;
    if (q == p) return -1;
    return std::atoi(s.substr(p, q - p).c_str());
}

// 0 = unknown/too weak, 1 = low, 2 = medium, 3 = high
int socClass(const std::string& socRaw) {
    std::string s = lower(socRaw);

    // Snapdragon marketing names ("snapdragon 662") and old model codes ("sdm660").
    int n = numberAfter(s, "snapdragon");
    if (n < 0) n = numberAfter(s, "sdm");
    if (n > 0) {
        if (n >= 800) return 3;
        if (n >= 700) return 2;
        if (n >= 600) return 1;
        return 0;
    }
    // Newer Qualcomm model codes: SM6115, SM7125, SM8250 ...
    n = numberAfter(s, "sm");
    if (n >= 1000) {
        int series = n / 1000;
        if (series >= 8) return 3;
        if (series == 7) return 2;
        if (series == 6) return 1;
        return 0;
    }
    n = numberAfter(s, "msm");  // MSM8953 = Snapdragon 625
    if (n >= 8000) return n >= 8990 ? 3 : (n >= 8976 ? 1 : (n >= 8953 ? 1 : 0));

    // MediaTek: MT6765 is the Helio P35 (e.g. Oppo A12).
    n = numberAfter(s, "mt");
    if (n >= 6000) {
        if (n < 6765) return 0;   // older/weaker MediaTek chips (e.g. MT6739, MT6761, MT6762 is borderline and excluded)
        if (n >= 6893) return 3;  // Dimensity 1xxx class and up
        if (n >= 6785) return 2;
        return 1;
    }
    if (s.find("helio") != std::string::npos) {
        int h = numberAfter(s, "helio p");
        if (h < 0) h = numberAfter(s, "helio g");
        if (h >= 35) return h >= 90 ? 2 : 1;
        return 0;
    }
    return -1;  // unrecognized
}

}  // namespace

const char* tierName(Tier t) {
    switch (t) {
        case Tier::Low: return "Low";
        case Tier::Medium: return "Medium";
        case Tier::High: return "High";
        default: return "Unsupported";
    }
}

DeviceVerdict evaluateDevice(const DeviceInfo& d) {
    DeviceVerdict v;

    if (d.ramMB < kMinRamMB) {
        v.reason = "Needs at least 3 GB of RAM.";
        return v;
    }
    if (d.glesMajor < 3) {
        v.reason = "Needs a GPU with OpenGL ES 3.0 support.";
        return v;
    }

    int cls = socClass(d.soc);
    if (cls == 0) {
        v.reason = "This chip is below the minimum (Snapdragon 6xx or MediaTek Helio P35).";
        return v;
    }
    std::string note;
    if (cls < 0) {
        // Unknown chip: only allow it on phones with plenty of RAM, and cap it at Low.
        if (d.ramMB < 3900) {
            v.reason = "Could not recognize this chip, and RAM is too low to take the risk.";
            return v;
        }
        cls = 1;
        note = " (chip not recognized, so the lowest quality tier was chosen)";
    }

    // RAM caps the tier.
    if (d.ramMB < 3900) cls = std::min(cls, 1);
    else if (d.ramMB < 5800) cls = std::min(cls, 2);

    v.tier = static_cast<Tier>(cls);
    v.reason = std::string("Supported, quality tier: ") + tierName(v.tier) + note + ".";
    return v;
}

}  // namespace cod3a

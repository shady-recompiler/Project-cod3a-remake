#pragma once
#include <string>

namespace cod3a {

enum class Tier { Unsupported = 0, Low = 1, Medium = 2, High = 3 };

struct DeviceInfo {
    int ramMB = 0;          // total RAM as reported by Android
    std::string soc;        // e.g. "SDM660", "MT6765", "Snapdragon 662"
    int glesMajor = 0;
    int glesMinor = 0;
};

struct DeviceVerdict {
    Tier tier = Tier::Unsupported;
    std::string reason;
};

// Minimum: ~3 GB RAM, Snapdragon 6xx or better, or MediaTek Helio P35 (MT6765) or better, GLES 3.0.
// The chip classification is a heuristic based on the SoC model string.
DeviceVerdict evaluateDevice(const DeviceInfo& d);

const char* tierName(Tier t);

}  // namespace cod3a

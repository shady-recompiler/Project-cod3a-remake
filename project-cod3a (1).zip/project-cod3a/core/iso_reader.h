#pragma once
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace cod3a {

struct IsoEntry {
    uint32_t lba = 0;
    uint32_t size = 0;
    bool isDir = false;
};

// Minimal ISO9660 reader for cooked 2048-byte-sector images.
class IsoReader {
public:
    IsoReader() = default;
    ~IsoReader();
    IsoReader(const IsoReader&) = delete;
    IsoReader& operator=(const IsoReader&) = delete;

    bool open(const std::string& path);
    bool openFd(int fd);  // for Android's content-resolver file descriptors (dup'd internally)

    // Path like "SYSTEM.CNF" or "DIR/FILE.BIN" (case-insensitive, ";1" suffix ignored).
    bool find(const std::string& path, IsoEntry& out);
    bool read(const IsoEntry& e, std::vector<uint8_t>& out, uint32_t maxBytes = 64u << 20);

private:
    bool readSector(uint32_t lba, uint8_t* buf);
    bool init();
    FILE* f_ = nullptr;
    IsoEntry root_;
};

}  // namespace cod3a

#include "core/iso_reader.h"

#include <algorithm>
#include <cctype>
#include <cstring>

#ifndef _WIN32
#include <unistd.h>
#endif

namespace cod3a {

static const uint32_t kSector = 2048;

static uint32_t le32(const uint8_t* p) {
    return uint32_t(p[0]) | (uint32_t(p[1]) << 8) | (uint32_t(p[2]) << 16) | (uint32_t(p[3]) << 24);
}

static std::string normalize(std::string s) {
    size_t semi = s.find(';');
    if (semi != std::string::npos) s.resize(semi);
    while (!s.empty() && s.back() == '.') s.pop_back();
    for (auto& c : s) c = char(std::toupper(static_cast<unsigned char>(c)));
    return s;
}

IsoReader::~IsoReader() {
    if (f_) fclose(f_);
}

bool IsoReader::open(const std::string& path) {
    if (f_) { fclose(f_); f_ = nullptr; }
    f_ = fopen(path.c_str(), "rb");
    return f_ && init();
}

bool IsoReader::openFd(int fd) {
#ifndef _WIN32
    if (f_) { fclose(f_); f_ = nullptr; }
    int d = dup(fd);
    if (d < 0) return false;
    f_ = fdopen(d, "rb");
    if (!f_) { close(d); return false; }
    return init();
#else
    (void)fd;
    return false;
#endif
}

bool IsoReader::readSector(uint32_t lba, uint8_t* buf) {
    if (!f_) return false;
    if (fseek(f_, long(uint64_t(lba) * kSector), SEEK_SET) != 0) return false;
    return fread(buf, 1, kSector, f_) == kSector;
}

bool IsoReader::init() {
    uint8_t pvd[kSector];
    if (!readSector(16, pvd)) return false;
    if (pvd[0] != 1 || std::memcmp(pvd + 1, "CD001", 5) != 0) return false;
    const uint8_t* rec = pvd + 156;
    root_.lba = le32(rec + 2);
    root_.size = le32(rec + 10);
    root_.isDir = true;
    return root_.size > 0 && root_.size < (16u << 20);
}

bool IsoReader::find(const std::string& path, IsoEntry& out) {
    if (!f_) return false;
    IsoEntry cur = root_;

    std::vector<std::string> parts;
    std::string part;
    for (char c : path) {
        if (c == '/' || c == '\\') {
            if (!part.empty()) parts.push_back(part);
            part.clear();
        } else {
            part += c;
        }
    }
    if (!part.empty()) parts.push_back(part);
    if (parts.empty()) return false;

    for (size_t i = 0; i < parts.size(); ++i) {
        if (!cur.isDir || cur.size > (16u << 20)) return false;
        std::vector<uint8_t> dir(((cur.size + kSector - 1) / kSector) * kSector);
        for (uint32_t s = 0; s < dir.size() / kSector; ++s) {
            if (!readSector(cur.lba + s, dir.data() + s * kSector)) return false;
        }
        const std::string want = normalize(parts[i]);
        bool found = false;
        size_t off = 0;
        while (off < cur.size) {
            uint8_t len = dir[off];
            if (len == 0) {  // records never span sectors; skip padding
                off = (off / kSector + 1) * kSector;
                continue;
            }
            if (off + len > dir.size() || len < 34) break;
            uint8_t nameLen = dir[off + 32];
            if (33u + nameLen > len) break;
            std::string name(reinterpret_cast<const char*>(&dir[off + 33]), nameLen);
            if (!(nameLen == 1 && (name[0] == '\0' || name[0] == '\1')) && normalize(name) == want) {
                cur.lba = le32(&dir[off + 2]);
                cur.size = le32(&dir[off + 10]);
                cur.isDir = (dir[off + 25] & 2) != 0;
                found = true;
                break;
            }
            off += len;
        }
        if (!found) return false;
    }
    out = cur;
    return true;
}

bool IsoReader::read(const IsoEntry& e, std::vector<uint8_t>& out, uint32_t maxBytes) {
    if (e.size > maxBytes) return false;
    uint32_t sectors = (e.size + kSector - 1) / kSector;
    std::vector<uint8_t> buf(size_t(sectors) * kSector);
    for (uint32_t s = 0; s < sectors; ++s) {
        if (!readSector(e.lba + s, buf.data() + size_t(s) * kSector)) return false;
    }
    buf.resize(e.size);
    out = std::move(buf);
    return true;
}

}  // namespace cod3a

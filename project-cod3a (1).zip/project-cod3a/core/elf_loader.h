#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace cod3a {

struct ElfSegment {
    uint32_t offset = 0;
    uint32_t vaddr = 0;
    uint32_t fileSize = 0;
    uint32_t memSize = 0;
    uint32_t flags = 0;  // 1 = X, 2 = W, 4 = R
};

struct ElfInfo {
    uint32_t entry = 0;
    std::vector<ElfSegment> loadSegments;
};

// Parses a 32-bit little-endian MIPS ELF (the PS2 Emotion Engine executable format).
bool parseElf(const std::vector<uint8_t>& data, ElfInfo& out, std::string& error);

}  // namespace cod3a
